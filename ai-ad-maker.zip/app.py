from flask import Flask, request, render_template
import openai
import os

app = Flask(__name__)

# Set your OpenAI API key (use environment variable for security)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/", methods=["GET", "POST"])
def generate_ad():
    ad_text = ""
    if request.method == "POST":
        content = request.form["content"]
        prompt = f"Create a creative and engaging advertisement for the following product or service:\n\n{content}\n\nAd:"

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a creative ad copywriter."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=150
        )

        ad_text = response['choices'][0]['message']['content'].strip()

    return render_template("index.html", ad_text=ad_text)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)