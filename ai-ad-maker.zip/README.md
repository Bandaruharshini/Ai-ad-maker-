# AI Ad Maker

This is a simple AI-powered ad generator built using Flask and OpenAI's GPT-4.

## Run Locally

```bash
pip install -r requirements.txt
export OPENAI_API_KEY=your-key-here
python app.py
```

## Deploy on Render

1. Connect GitHub repo.
2. Add `OPENAI_API_KEY` in environment variables.
3. Set build command: `pip install -r requirements.txt`
4. Start command: `python app.py`